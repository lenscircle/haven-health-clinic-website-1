(() => {
  "use strict";

  const menuToggle = document.getElementById("menuToggle");
  const primaryNav = document.getElementById("primaryNav");
  const form = document.getElementById("appointmentForm");
  const formMessage = document.getElementById("formMessage");
  const submitButton = document.getElementById("submitAppointment");
  const dateInput = document.getElementById("preferredDate");

  document.getElementById("currentYear").textContent = new Date().getFullYear();

  // Mobile navigation
  menuToggle?.addEventListener("click", () => {
    const isOpen = primaryNav.classList.toggle("open");
    menuToggle.setAttribute("aria-expanded", String(isOpen));
    menuToggle.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
  });
  primaryNav?.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      primaryNav.classList.remove("open");
      menuToggle?.setAttribute("aria-expanded", "false");
      menuToggle?.setAttribute("aria-label", "Open navigation");
    });
  });

  // Do not allow appointment requests for a past date.
  if (dateInput) {
    const today = new Date();
    const localToday = new Date(today.getTime() - today.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
    dateInput.min = localToday;
  }

  const config = window.HAVEN_CONFIG || {};
  const hasSupabaseConfig = Boolean(config.SUPABASE_URL && config.SUPABASE_ANON_KEY);
  let supabaseClient = null;
  if (hasSupabaseConfig && window.supabase?.createClient) {
    try {
      supabaseClient = window.supabase.createClient(config.SUPABASE_URL, config.SUPABASE_ANON_KEY);
    } catch (error) {
      console.error("Supabase could not be initialised:", error);
    }
  }

  function showMessage(message, type) {
    formMessage.textContent = message;
    formMessage.className = `form-message is-visible ${type}`;
  }

  function normalisePhone(phone) {
    return phone.replace(/[\s()+-]/g, "");
  }

  function validateForm(data) {
    const phone = normalisePhone(data.phone || "");
    if (!data.fullName || data.fullName.trim().length < 2) return "Please enter your full name.";
    if (!/^\d{10,13}$/.test(phone)) return "Please enter a valid phone number (10–13 digits, excluding the country code symbols).";
    if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) return "Please enter a valid email address.";
    if (!data.service) return "Please choose a reason for your visit.";
    if (!data.preferredDate) return "Please choose a preferred date.";
    if (data.preferredDate < dateInput.min) return "Please choose today or a future date.";
    if (!document.getElementById("consent").checked) return "Please agree to be contacted about this request.";
    return "";
  }

  form?.addEventListener("submit", async (event) => {
    event.preventDefault();
    formMessage.className = "form-message";

    const values = Object.fromEntries(new FormData(form).entries());
    const error = validateForm(values);
    if (error) {
      showMessage(error, "error");
      return;
    }

    const record = {
      full_name: values.fullName.trim(),
      phone: values.phone.trim(),
      email: values.email.trim() || null,
      service: values.service,
      preferred_date: values.preferredDate,
      preferred_time: values.preferredTime || null,
      notes: values.notes.trim() || null
    };

    submitButton.disabled = true;
    submitButton.innerHTML = 'Sending request <span aria-hidden="true">…</span>';

    try {
      if (supabaseClient) {
        const { error: insertError } = await supabaseClient.from("appointments").insert([record]);
        if (insertError) throw insertError;
        showMessage("Thank you. Your appointment request has been sent to the clinic. The team will contact you to confirm availability.", "success");
      } else {
        const storageKey = "haven_demo_appointment_requests";
        const existing = JSON.parse(localStorage.getItem(storageKey) || "[]");
        existing.push({ ...record, created_at: new Date().toISOString(), demo: true });
        localStorage.setItem(storageKey, JSON.stringify(existing));
        showMessage("Demo request saved in this browser. No clinic has been notified. Connect Supabase to receive requests online.", "success");
      }
      form.reset();
      if (dateInput) {
        const today = new Date();
        dateInput.min = new Date(today.getTime() - today.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
      }
    } catch (error) {
      console.error("Appointment request failed:", error);
      showMessage("We couldn't send the request. Please try again or contact the clinic by phone.", "error");
    } finally {
      submitButton.disabled = false;
      submitButton.innerHTML = 'Send appointment request <span aria-hidden="true">↗</span>';
    }
  });
})();
