/*
  Optional Supabase configuration.
  Leave these values unchanged to run the site in demo mode (browser localStorage).
  To connect Supabase, add your Project URL and anon/public key here.
  NEVER place a service_role key or any other secret in frontend code.
*/
window.HAVEN_CONFIG = {
  SUPABASE_URL: "",
  SUPABASE_ANON_KEY: ""
};
